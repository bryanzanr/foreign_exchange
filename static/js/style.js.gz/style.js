$( document ).ready(function(){
	$('.dropdown-button').dropdown({
      belowOrigin: true, // Displays dropdown below the button
    }
  	);
});