$(document).ready(function(){
    // $('#broadcast').on('click',function(){
    //    $.get( "{% url 'execute' %}", function( data ) {
    //        alert( "Successfully Post Advertisements." );
    //    });
    // }); 
});